package com.example.mojeapi;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.TextView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_INTERNET_PERMISSION = ;
    public final int REQUEST_CAMERA_PERMISSION = 1;
    private TextView textView;

    private ApiService apiService;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView=findViewById(R.id.nig);

        apiService = ApiClient.getRetrofitInstance().create(ApiService.class);
        // Przykład wywołania API (GET request)
        Call<Zloto[]> call = apiService.getUser();
        call.enqueue(new Callback<Zloto[]>() {
            @Override
            public void onResponse(Call<Zloto[]> call, Response<Zloto[]> response) {
                if (response.isSuccessful()) {
                    Zloto[] zloto = response.body();
                    textView.setText(zloto.getClass()+"");
                    // Obsługa danych użytkownika
                } else {
                    // Obsługa błędów
                }
            }
            @Override
            public void onFailure(Call<Zloto[]> call, Throwable t) {
            }
        });
    }
    private void action(View v) {
        Activity ActivityCompat;
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.INTERNET)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.INTERNET}, REQUEST_INTERNET_PERMISSION);
            return;
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_INTERNET_PERMISSION && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(getApplicationContext(), "Przyznano uprawnienia", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(getApplicationContext(), "Nie przyznano uprawnień", Toast.LENGTH_LONG).show();
        }
    }

}

